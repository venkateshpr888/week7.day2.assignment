package testcase1_ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooksForMultilingualUsingPOM.BasePage;
import testcase1_ForPageObjectModel.CreateContactsPage;

public class MyContactsPage extends BasePage {
//	public MyLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public CreateContactsPage clickcontact1() {
		getDriver().findElement(By.linkText(prop1.getProperty("contactTab"))).click();	
		return new CreateContactsPage();
	}

}
