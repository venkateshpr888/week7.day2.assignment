package testcase1_ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooksForMultilingualUsingPOM.BasePage;
import testcase1_ForPageObjectModel.MyContactsPage;

public class MyHomePage extends BasePage {
//	public MyHomePage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public MyContactsPage ClickContactsTab1() {
		getDriver().findElement(By.linkText("Contacts")).click();
		return new MyContactsPage();
	}
	
}
