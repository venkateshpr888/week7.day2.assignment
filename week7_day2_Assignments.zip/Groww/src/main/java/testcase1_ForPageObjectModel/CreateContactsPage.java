package testcase1_ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooksForMultilingualUsingPOM.BasePage;
import testcase1_ForPageObjectModel.CreateContactsPage;
import testcase1_ForPageObjectModel.ViewContactsPage;

public class CreateContactsPage extends BasePage{
//	public CreateLeadPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	
	


	public CreateContactsPage typeFirstName1(String fname) {
		getDriver().findElement(By.id("firstNameField")).sendKeys(fname);
		return this;
	}
	public CreateContactsPage typeLastName1(String lname) {
		getDriver().findElement(By.id("lastNameField")).sendKeys(lname);
		return this;
	}
	
public ViewContactsPage clickSubmit1() {
	getDriver().findElement(By.name("submitButton")).click();
	return new ViewContactsPage();
}
}