package testcase1_ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooksForMultilingualUsingPOM.BasePage;
import testcase1_ForPageObjectModel.ViewContactsPage;

public class ViewContactsPage extends BasePage {
//	public ViewLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public ViewContactsPage verifyFirstName1() {
		String text = getDriver().findElement(By.id("viewContact_firstName_sp")).getText();
	    System.out.println("First name in Create Contact = "+text);
		System.out.println("TC1 Successfull");
		return this;
	}

}
