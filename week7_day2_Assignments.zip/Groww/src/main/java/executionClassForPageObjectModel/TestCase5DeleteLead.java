package executionClassForPageObjectModel;

import org.testng.annotations.Test;

import hooksForMultilingualUsingPOM.BasePage;
import testCase5ForPageObjectModel.LoginPage5forDelete;




public class TestCase5DeleteLead extends BasePage{

	@Test
	public void DeleteLead() throws InterruptedException {
		new LoginPage5forDelete()
		.typeUserName5("DemoCsr2")
		.typePassword5("crmsfa")
		.clickLogin5()
		.clickCRMSFA5()
		.clickLeadsTab5()
		.clickFindLead5()
		.clickEmailTab5()
		.typeEmailAddress5("venkatesh@gmail.com")
		.clickFind5()
		.clickFirstName5()
		.ClickDelete5()
		.ClickfindLeadToDelete5()
		.ClickNameTab5()
		.VerifyDeleteLead5();
		}
	
}
