package testCase2ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooksForMultilingualUsingPOM.BasePage;

public class MyLeadsPage extends BasePage {
//	public MyLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public CreateLeadPage clickcreateLead2() {
		getDriver().findElement(By.linkText(prop1.getProperty("linklead"))).click();	
		return new CreateLeadPage();
	}

}
