package testCase3ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooksForMultilingualUsingPOM.BasePage;

public class MyLeadsPage extends BasePage {
//	public MyLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public ViewLeadsPage clickFindLead3() {
		getDriver().findElement(By.xpath("//a[@href='/crmsfa/control/findLeads']")).click();	
		return new ViewLeadsPage();
	}

}
