package testCase3ForPageObjectModel;

import org.openqa.selenium.By;

import hooksForMultilingualUsingPOM.BasePage;

public class EditLeadPage extends BasePage{
	public EditLeadPage clickEditTab3() {
		getDriver().findElement(By.xpath("//a[text()='Modifier']")).click();
		
		return this;
	}
	
	public EditLeadPage changeCompanyName3(String Cname) {
		getDriver().findElement(By.id("updateLeadForm_companyName")).sendKeys(Cname);
		
		return this;
	}
	public ViewLeadsPage ClickSubmit3() {
		getDriver().findElement(By.xpath("//input[@name='submitButton'][1]")).click();
		
		return new ViewLeadsPage();
	}
	
	
}
//driver.findElement(By.xpath("//a[text()='Edit']")).click();
//driver.findElement(By.id("updateLeadForm_companyName")).sendKeys("LEAF TEST");
//driver.findElement(By.xpath("//input[@name='submitButton'][1]")).click();