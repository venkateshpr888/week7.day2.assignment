package testCase4ForPageObjectModel;

import org.openqa.selenium.By;

import hooksForMultilingualUsingPOM.BasePage;

public class DuplicateLeadPage extends BasePage {
	public ViewLeadPage clickCreateLead4() throws InterruptedException {
		getDriver().findElement(By.xpath("//input[@name='submitButton']")).click();
		Thread.sleep(3000);
		return new ViewLeadPage();
}
}
