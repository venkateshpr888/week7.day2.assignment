package testCase4ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooksForMultilingualUsingPOM.BasePage;
import testCase3ForPageObjectModel.ViewLeadsPage;

public class MyLeadsPage extends BasePage {
//	public MyLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public FindLeadsPage clickFindLead4() {
		getDriver().findElement(By.xpath("//a[@href='/crmsfa/control/findLeads']")).click();	
		return new FindLeadsPage();
	}

}
