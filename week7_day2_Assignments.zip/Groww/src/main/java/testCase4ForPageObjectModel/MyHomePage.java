package testCase4ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooksForMultilingualUsingPOM.BasePage;

public class MyHomePage extends BasePage{
//	public MyHomePage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public MyLeadsPage clickLeadsTab4() {
		getDriver().findElement(By.linkText(prop1.getProperty("linkcreatelead"))).click();
		return new MyLeadsPage();
	}
	
}
